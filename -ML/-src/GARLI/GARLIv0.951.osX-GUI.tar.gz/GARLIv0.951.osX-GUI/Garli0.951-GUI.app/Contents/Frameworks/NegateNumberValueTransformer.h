//
//  NegateNumberValueTransformer.h
//  GARLI
//
//  Created by Jim Balhoff on 10/11/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Foundation/Foundation.h>


@interface NegateNumberValueTransformer : NSValueTransformer {

}

@end
