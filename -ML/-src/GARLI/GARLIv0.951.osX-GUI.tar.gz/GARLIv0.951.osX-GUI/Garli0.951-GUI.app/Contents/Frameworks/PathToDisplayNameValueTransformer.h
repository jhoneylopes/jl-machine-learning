//
//  PathToDisplayNameValueTransformer.h
//  GARLI
//
//  Created by Jim Balhoff on 10/26/06.
//  Copyright 2006 __MyCompanyName__. All rights reserved.
//

#import <Cocoa/Cocoa.h>


@interface PathToDisplayNameValueTransformer : NSValueTransformer
{
}

@end
